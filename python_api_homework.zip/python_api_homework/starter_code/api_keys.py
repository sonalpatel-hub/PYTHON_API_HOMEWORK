# OpenWeatherMap API Key
api_key = "YOU API KEY HERE"
